# 📱 WA Sender — WhatsApp Bulk Sender

App web completo para disparar mensagens WhatsApp para uma lista de clientes via Excel.

---

## 🚀 Como rodar localmente

### Pré-requisitos
- Node.js 18+ instalado

### 1. Instalar dependências

```bash
npm run install:all
```

### 2. Configurar variáveis de ambiente

```bash
cd backend
cp .env.example .env
```

Edite o `.env` e defina:
- `JWT_SECRET` → qualquer string longa e aleatória
- `ADMIN_USER` → seu usuário de login
- `ADMIN_PASS` → sua senha de login

### 3. Rodar em desenvolvimento

```bash
npm run dev
```

- Frontend: http://localhost:5173
- Backend: http://localhost:3001

---

## 🌐 Hospedagem no Railway (gratuito)

1. Crie uma conta em [railway.app](https://railway.app)
2. Clique em **New Project → Deploy from GitHub**
3. Conecte seu repositório
4. Em **Settings → Variables**, adicione as variáveis do `.env`
5. Em **Settings → Start Command**, coloque:
   ```
   npm run build && npm start
   ```
6. Pronto! Railway gera uma URL pública automaticamente.

---

## 📋 Como usar o app

1. **Configurações** → Cole seu Token e Phone Number ID da Meta
2. **Novo Disparo** → Arraste o Excel com colunas `nome` e `telefone`
3. Informe o nome do template aprovado no Meta Business Manager
4. Clique em **Disparar** e acompanhe em tempo real
5. **Histórico** → Veja todas as campanhas anteriores com detalhes

---

## 📊 Formato do Excel esperado

| nome         | telefone        |
|--------------|-----------------|
| João Silva   | 11999998888     |
| Maria Souza  | 21988887777     |

- A coluna de telefone aceita: `telefone`, `phone`, `celular`, `whatsapp`, `fone`
- Números com menos de 10 dígitos são ignorados
- O código do país (55) é adicionado automaticamente

---

## ⚠️ Importante — WhatsApp Business API

- Mensagens só podem ser enviadas via **templates aprovados pela Meta**
- Crie os templates em: Meta Business Manager → WhatsApp → Message Templates
- O primeiro parâmetro do template recebe o **nome do cliente** automaticamente
- Para testes, a Meta oferece um número gratuito com até 5 contatos

---

## 🗂 Estrutura do projeto

```
whatsapp-sender/
├── backend/
│   ├── server.js      # API Express + lógica de disparo
│   ├── db.js          # SQLite (campanhas e contatos)
│   └── .env.example
├── frontend/
│   └── src/
│       ├── pages/     # Login, Send, Campaigns, CampaignDetail, Settings
│       ├── components/# Layout (sidebar)
│       └── hooks/     # useAuth
└── package.json       # Scripts do monorepo
```
