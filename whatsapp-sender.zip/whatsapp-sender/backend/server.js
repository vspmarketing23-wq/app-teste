require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const XLSX = require('xlsx');
const fetch = require('node-fetch');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_in_prod';
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || 'admin123';

app.use(cors());
app.use(express.json());

// Servir frontend em produção
app.use(express.static(path.join(__dirname, '../frontend/dist')));

// --- Auth ---
const upload = multer({ storage: multer.memoryStorage() });

function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Token ausente' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Token inválido' });
  }
}

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  if (username !== ADMIN_USER || password !== ADMIN_PASS) {
    return res.status(401).json({ error: 'Usuário ou senha incorretos' });
  }
  const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token });
});

// --- Configurações WhatsApp ---
app.get('/api/settings', authMiddleware, (req, res) => {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const settings = {};
  rows.forEach(r => settings[r.key] = r.value);
  res.json(settings);
});

app.post('/api/settings', authMiddleware, (req, res) => {
  const { waba_token, phone_number_id } = req.body;
  const upsert = db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
  if (waba_token !== undefined) upsert.run('waba_token', waba_token);
  if (phone_number_id !== undefined) upsert.run('phone_number_id', phone_number_id);
  res.json({ ok: true });
});

// --- Upload Excel ---
app.post('/api/parse-excel', authMiddleware, upload.single('file'), (req, res) => {
  try {
    const wb = XLSX.read(req.file.buffer, { type: 'buffer' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const data = XLSX.utils.sheet_to_json(ws, { defval: '' });
    if (!data.length) return res.status(400).json({ error: 'Planilha vazia' });

    const contacts = data.map(row => {
      const nameKey = Object.keys(row).find(k => /nome|name/i.test(k)) || Object.keys(row)[0];
      const phoneKey = Object.keys(row).find(k => /telefone|phone|cel|whatsapp|fone/i.test(k));
      if (!phoneKey) return null;
      const phone = String(row[phoneKey]).replace(/\D/g, '');
      if (phone.length < 10) return null;
      return { name: String(row[nameKey] || ''), phone };
    }).filter(Boolean);

    res.json({ contacts, total: contacts.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- Campanhas ---
app.get('/api/campaigns', authMiddleware, (req, res) => {
  const campaigns = db.prepare('SELECT * FROM campaigns ORDER BY created_at DESC').all();
  res.json(campaigns);
});

app.get('/api/campaigns/:id', authMiddleware, (req, res) => {
  const campaign = db.prepare('SELECT * FROM campaigns WHERE id=?').get(req.params.id);
  if (!campaign) return res.status(404).json({ error: 'Campanha não encontrada' });
  const contacts = db.prepare('SELECT * FROM campaign_contacts WHERE campaign_id=?').all(req.params.id);
  res.json({ ...campaign, contacts });
});

// --- Disparo ---
app.post('/api/campaigns/send', authMiddleware, async (req, res) => {
  const { name, template, contacts } = req.body;
  if (!contacts?.length) return res.status(400).json({ error: 'Nenhum contato' });

  const settings = {};
  db.prepare('SELECT key, value FROM settings').all().forEach(r => settings[r.key] = r.value);
  const { waba_token, phone_number_id } = settings;
  if (!waba_token || !phone_number_id) return res.status(400).json({ error: 'Configure as credenciais do WhatsApp primeiro' });

  const insertCampaign = db.prepare('INSERT INTO campaigns(name, template, total, status) VALUES(?,?,?,?)');
  const campaignId = insertCampaign.run(name || `Campanha ${new Date().toLocaleDateString('pt-BR')}`, template, contacts.length, 'running').lastInsertRowid;

  const insertContact = db.prepare('INSERT INTO campaign_contacts(campaign_id, name, phone) VALUES(?,?,?)');
  contacts.forEach(c => insertContact.run(campaignId, c.name, c.phone));

  res.json({ campaignId });

  // Disparo em background
  (async () => {
    let sent = 0, errors = 0;
    const allContacts = db.prepare('SELECT * FROM campaign_contacts WHERE campaign_id=?').all(campaignId);

    for (const contact of allContacts) {
      await new Promise(r => setTimeout(r, 300));
      try {
        const body = {
          messaging_product: 'whatsapp',
          to: '55' + contact.phone,
          type: 'template',
          template: {
            name: template,
            language: { code: 'pt_BR' },
            components: [{ type: 'body', parameters: [{ type: 'text', text: contact.name }] }]
          }
        };
        const resp = await fetch(`https://graph.facebook.com/v19.0/${phone_number_id}/messages`, {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${waba_token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify(body)
        });
        const data = await resp.json();
        if (resp.ok && data.messages) {
          db.prepare('UPDATE campaign_contacts SET status=?, sent_at=CURRENT_TIMESTAMP WHERE id=?').run('sent', contact.id);
          sent++;
        } else {
          const errMsg = data.error?.message || 'Erro desconhecido';
          db.prepare('UPDATE campaign_contacts SET status=?, error_msg=? WHERE id=?').run('error', errMsg, contact.id);
          errors++;
        }
      } catch (e) {
        db.prepare('UPDATE campaign_contacts SET status=?, error_msg=? WHERE id=?').run('error', e.message, contact.id);
        errors++;
      }
      db.prepare('UPDATE campaigns SET sent=?, errors=? WHERE id=?').run(sent, errors, campaignId);
    }
    db.prepare('UPDATE campaigns SET status=?, finished_at=CURRENT_TIMESTAMP WHERE id=?').run('finished', campaignId);
  })();
});

// --- Status polling ---
app.get('/api/campaigns/:id/status', authMiddleware, (req, res) => {
  const campaign = db.prepare('SELECT * FROM campaigns WHERE id=?').get(req.params.id);
  if (!campaign) return res.status(404).json({ error: 'Não encontrado' });
  const contacts = db.prepare('SELECT * FROM campaign_contacts WHERE campaign_id=? ORDER BY id').all(req.params.id);
  res.json({ ...campaign, contacts });
});

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/dist/index.html'));
});

app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
