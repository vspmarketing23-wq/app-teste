import React, { useState } from 'react'

export default function Login({ onLogin }) {
  const [user, setUser] = useState('')
  const [pass, setPass] = useState('')
  const [err, setErr] = useState('')
  const [loading, setLoading] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setLoading(true); setErr('')
    try {
      await onLogin(user, pass)
    } catch {
      setErr('Usuário ou senha incorretos')
    }
    setLoading(false)
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#F9F9F8' }}>
      <div className="card" style={{ width: 360 }}>
        <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>📱</div>
          <h1 style={{ fontSize: 20, fontWeight: 600 }}>WA Sender</h1>
          <p style={{ fontSize: 13, color: '#888780', marginTop: 4 }}>Faça login para continuar</p>
        </div>
        <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div>
            <label style={{ fontSize: 13, color: '#444441', display: 'block', marginBottom: 4 }}>Usuário</label>
            <input value={user} onChange={e => setUser(e.target.value)} style={{ width: '100%' }} required />
          </div>
          <div>
            <label style={{ fontSize: 13, color: '#444441', display: 'block', marginBottom: 4 }}>Senha</label>
            <input type="password" value={pass} onChange={e => setPass(e.target.value)} style={{ width: '100%' }} required />
          </div>
          {err && <p style={{ fontSize: 13, color: '#E24B4A' }}>{err}</p>}
          <button type="submit" className="primary" disabled={loading} style={{ width: '100%', padding: '10px', marginTop: 4 }}>
            {loading ? 'Entrando...' : 'Entrar'}
          </button>
        </form>
      </div>
    </div>
  )
}
