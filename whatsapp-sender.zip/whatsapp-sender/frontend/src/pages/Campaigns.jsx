import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

export default function Campaigns() {
  const [campaigns, setCampaigns] = useState([])
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    axios.get('/api/campaigns').then(r => { setCampaigns(r.data); setLoading(false) })
  }, [])

  const statusLabel = { pending: 'Pendente', running: 'Enviando...', finished: 'Concluído' }
  const statusClass = { pending: 'badge-pending', running: 'badge-running', finished: 'badge-success' }

  if (loading) return <div className="page"><p style={{ color: '#888780' }}>Carregando...</p></div>

  return (
    <div className="page">
      <h1 className="page-title">📋 Histórico de disparos</h1>
      {campaigns.length === 0
        ? <div className="card" style={{ textAlign: 'center', padding: '2.5rem', color: '#888780' }}>
            <p style={{ fontSize: 32, marginBottom: 8 }}>📭</p>
            <p>Nenhuma campanha ainda. Faça seu primeiro disparo!</p>
          </div>
        : <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {campaigns.map(c => (
              <div key={c.id} className="card" style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}
                onClick={() => navigate(`/campaigns/${c.id}`)}>
                <div>
                  <p style={{ fontWeight: 500 }}>{c.name}</p>
                  <p style={{ fontSize: 13, color: '#888780', marginTop: 2 }}>
                    Template: <strong>{c.template}</strong> · {new Date(c.created_at).toLocaleString('pt-BR')}
                  </p>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0 }}>
                  <span style={{ fontSize: 13, color: '#444441' }}>
                    {c.sent}/{c.total} enviados
                    {c.errors > 0 && <span style={{ color: '#E24B4A', marginLeft: 6 }}>· {c.errors} erros</span>}
                  </span>
                  <span className={`badge ${statusClass[c.status] || 'badge-pending'}`}>{statusLabel[c.status] || c.status}</span>
                </div>
              </div>
            ))}
          </div>
      }
    </div>
  )
}
