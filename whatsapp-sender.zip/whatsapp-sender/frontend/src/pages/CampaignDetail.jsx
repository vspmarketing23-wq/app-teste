import React, { useState, useEffect, useRef } from 'react'
import axios from 'axios'
import { useParams, useNavigate } from 'react-router-dom'

export default function CampaignDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [data, setData] = useState(null)
  const intervalRef = useRef()

  const fetch = () => {
    axios.get(`/api/campaigns/${id}/status`).then(r => {
      setData(r.data)
      if (r.data.status === 'finished') clearInterval(intervalRef.current)
    })
  }

  useEffect(() => {
    fetch()
    intervalRef.current = setInterval(fetch, 1500)
    return () => clearInterval(intervalRef.current)
  }, [id])

  if (!data) return <div className="page"><p style={{ color: '#888780' }}>Carregando...</p></div>

  const pct = data.total > 0 ? Math.round((data.sent + data.errors) / data.total * 100) : 0

  return (
    <div className="page">
      <button onClick={() => navigate('/campaigns')} style={{ fontSize: 13, marginBottom: '1rem', border: 'none', background: 'none', padding: 0, color: '#888780', cursor: 'pointer' }}>
        ← Voltar
      </button>
      <h1 className="page-title">{data.name}</h1>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginBottom: '1.5rem' }}>
        {[
          { label: 'Total', value: data.total },
          { label: 'Enviados', value: data.sent, color: '#0F6E56' },
          { label: 'Erros', value: data.errors, color: data.errors > 0 ? '#E24B4A' : undefined },
          { label: 'Progresso', value: pct + '%' }
        ].map(s => (
          <div key={s.label} style={{ background: '#F9F9F8', border: '1px solid #F1EFE8', borderRadius: 8, padding: '12px 14px' }}>
            <p style={{ fontSize: 12, color: '#888780', marginBottom: 4 }}>{s.label}</p>
            <p style={{ fontSize: 22, fontWeight: 600, color: s.color || '#1a1a18' }}>{s.value}</p>
          </div>
        ))}
      </div>

      <div style={{ background: '#F1EFE8', borderRadius: 4, height: 6, marginBottom: '1.5rem' }}>
        <div style={{ width: pct + '%', height: 6, background: '#1D9E75', borderRadius: 4, transition: 'width 0.4s' }} />
      </div>

      {data.status === 'running' && (
        <p style={{ fontSize: 13, color: '#854F0B', background: '#FAEEDA', padding: '8px 14px', borderRadius: 6, marginBottom: '1rem' }}>
          ⏳ Disparo em andamento... atualizando automaticamente.
        </p>
      )}

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ maxHeight: 420, overflowY: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead style={{ background: '#F9F9F8', position: 'sticky', top: 0 }}>
              <tr>
                <th style={{ padding: '8px 12px', textAlign: 'left', color: '#888780', fontWeight: 500 }}>Nome</th>
                <th style={{ padding: '8px 12px', textAlign: 'left', color: '#888780', fontWeight: 500 }}>Telefone</th>
                <th style={{ padding: '8px 12px', textAlign: 'left', color: '#888780', fontWeight: 500 }}>Status</th>
                <th style={{ padding: '8px 12px', textAlign: 'left', color: '#888780', fontWeight: 500 }}>Detalhe</th>
              </tr>
            </thead>
            <tbody>
              {data.contacts?.map(c => (
                <tr key={c.id} style={{ borderTop: '1px solid #F1EFE8' }}>
                  <td style={{ padding: '7px 12px' }}>{c.name || '—'}</td>
                  <td style={{ padding: '7px 12px', color: '#888780' }}>{c.phone}</td>
                  <td style={{ padding: '7px 12px' }}>
                    <span className={`badge ${c.status === 'sent' ? 'badge-success' : c.status === 'error' ? 'badge-error' : 'badge-pending'}`}>
                      {c.status === 'sent' ? 'Enviado' : c.status === 'error' ? 'Erro' : 'Pendente'}
                    </span>
                  </td>
                  <td style={{ padding: '7px 12px', fontSize: 12, color: '#888780' }}>{c.error_msg || (c.sent_at ? new Date(c.sent_at).toLocaleTimeString('pt-BR') : '')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
