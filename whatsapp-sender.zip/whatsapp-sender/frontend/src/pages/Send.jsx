import React, { useState, useRef, useEffect } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import * as XLSX from 'xlsx'

export default function Send() {
  const [contacts, setContacts] = useState([])
  const [fileName, setFileName] = useState('')
  const [template, setTemplate] = useState('')
  const [campaignName, setCampaignName] = useState('')
  const [sending, setSending] = useState(false)
  const [dragOver, setDragOver] = useState(false)
  const [error, setError] = useState('')
  const fileRef = useRef()
  const navigate = useNavigate()

  const processFile = (file) => {
    setError('')
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(e.target.result, { type: 'array' })
        const ws = wb.Sheets[wb.SheetNames[0]]
        const data = XLSX.utils.sheet_to_json(ws, { defval: '' })
        const parsed = data.map(row => {
          const nameKey = Object.keys(row).find(k => /nome|name/i.test(k)) || Object.keys(row)[0]
          const phoneKey = Object.keys(row).find(k => /telefone|phone|cel|whatsapp|fone/i.test(k))
          if (!phoneKey) return null
          const phone = String(row[phoneKey]).replace(/\D/g, '')
          if (phone.length < 10) return null
          return { name: String(row[nameKey] || ''), phone }
        }).filter(Boolean)
        if (!parsed.length) { setError('Nenhum contato válido encontrado. Verifique as colunas nome e telefone.'); return }
        setContacts(parsed)
        setFileName(file.name)
      } catch (err) {
        setError('Erro ao ler o arquivo: ' + err.message)
      }
    }
    reader.readAsArrayBuffer(file)
  }

  const send = async () => {
    if (!template) { setError('Informe o nome do template'); return }
    setSending(true); setError('')
    try {
      const res = await axios.post('/api/campaigns/send', { name: campaignName, template, contacts })
      navigate(`/campaigns/${res.data.campaignId}`)
    } catch (err) {
      setError(err.response?.data?.error || 'Erro ao iniciar disparo')
      setSending(false)
    }
  }

  return (
    <div className="page">
      <h1 className="page-title">📤 Novo Disparo</h1>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>

        <div className="card">
          <h2 style={{ fontSize: 15, fontWeight: 600, marginBottom: '1rem' }}>1. Carregar lista de clientes</h2>
          <div
            onDragOver={e => { e.preventDefault(); setDragOver(true) }}
            onDragLeave={() => setDragOver(false)}
            onDrop={e => { e.preventDefault(); setDragOver(false); if (e.dataTransfer.files[0]) processFile(e.dataTransfer.files[0]) }}
            onClick={() => fileRef.current.click()}
            style={{
              border: `2px dashed ${dragOver ? '#1D9E75' : '#D3D1C7'}`,
              borderRadius: 8, padding: '1.5rem', textAlign: 'center', cursor: 'pointer',
              background: dragOver ? '#E1F5EE' : 'transparent', color: '#888780', fontSize: 14,
              transition: 'all 0.15s'
            }}
          >
            {contacts.length > 0
              ? <><span style={{ fontSize: 24 }}>✅</span><br /><strong style={{ color: '#0F6E56' }}>{fileName}</strong><br /><span style={{ fontSize: 13 }}>{contacts.length} contatos carregados</span></>
              : <><span style={{ fontSize: 24 }}>📂</span><br />Clique ou arraste o arquivo .xlsx aqui<br /><span style={{ fontSize: 12 }}>Colunas necessárias: nome e telefone</span></>
            }
          </div>
          <input ref={fileRef} type="file" accept=".xlsx,.xls" style={{ display: 'none' }} onChange={e => { if (e.target.files[0]) processFile(e.target.files[0]) }} />

          {contacts.length > 0 && (
            <div style={{ marginTop: '1rem' }}>
              <div style={{ maxHeight: 200, overflowY: 'auto', border: '1px solid #D3D1C7', borderRadius: 6 }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                  <thead style={{ background: '#F9F9F8', position: 'sticky', top: 0 }}>
                    <tr>
                      <th style={{ padding: '6px 10px', textAlign: 'left', color: '#888780', fontWeight: 500 }}>Nome</th>
                      <th style={{ padding: '6px 10px', textAlign: 'left', color: '#888780', fontWeight: 500 }}>Telefone</th>
                    </tr>
                  </thead>
                  <tbody>
                    {contacts.map((c, i) => (
                      <tr key={i} style={{ borderTop: '1px solid #F1EFE8' }}>
                        <td style={{ padding: '6px 10px' }}>{c.name || '—'}</td>
                        <td style={{ padding: '6px 10px', color: '#888780' }}>{c.phone}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <button onClick={() => { setContacts([]); setFileName('') }} style={{ marginTop: 8, fontSize: 12, color: '#E24B4A', border: 'none', background: 'none', padding: 0 }}>
                Remover lista
              </button>
            </div>
          )}
        </div>

        <div className="card">
          <h2 style={{ fontSize: 15, fontWeight: 600, marginBottom: '1rem' }}>2. Configurar mensagem</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div>
              <label style={{ fontSize: 13, color: '#444441', display: 'block', marginBottom: 4 }}>Nome da campanha (opcional)</label>
              <input value={campaignName} onChange={e => setCampaignName(e.target.value)} placeholder="Ex: Promoção Maio 2025" style={{ width: '100%' }} />
            </div>
            <div>
              <label style={{ fontSize: 13, color: '#444441', display: 'block', marginBottom: 4 }}>Nome do template aprovado <span style={{ color: '#E24B4A' }}>*</span></label>
              <input value={template} onChange={e => setTemplate(e.target.value)} placeholder="Ex: boas_vindas, lembrete_cobranca..." style={{ width: '100%' }} />
              <p style={{ fontSize: 12, color: '#888780', marginTop: 4 }}>O template deve estar aprovado no Meta Business Manager. O primeiro parâmetro será o nome do cliente.</p>
            </div>
          </div>
        </div>

        {error && <p style={{ fontSize: 13, color: '#E24B4A', background: '#FCEBEB', padding: '10px 14px', borderRadius: 6 }}>{error}</p>}

        <button
          className="primary"
          onClick={send}
          disabled={sending || !contacts.length}
          style={{ padding: '12px', fontSize: 15 }}
        >
          {sending ? 'Iniciando disparo...' : `🚀 Disparar para ${contacts.length} contatos`}
        </button>
      </div>
    </div>
  )
}
