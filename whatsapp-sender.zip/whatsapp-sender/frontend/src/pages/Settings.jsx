import React, { useState, useEffect } from 'react'
import axios from 'axios'

export default function Settings() {
  const [token, setToken] = useState('')
  const [phoneId, setPhoneId] = useState('')
  const [saved, setSaved] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    axios.get('/api/settings').then(r => {
      setToken(r.data.waba_token || '')
      setPhoneId(r.data.phone_number_id || '')
      setLoading(false)
    })
  }, [])

  const save = async (e) => {
    e.preventDefault()
    await axios.post('/api/settings', { waba_token: token, phone_number_id: phoneId })
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  if (loading) return <div className="page"><p style={{ color: '#888780' }}>Carregando...</p></div>

  return (
    <div className="page">
      <h1 className="page-title">⚙️ Configurações</h1>
      <div className="card" style={{ maxWidth: 520 }}>
        <h2 style={{ fontSize: 15, fontWeight: 600, marginBottom: '1rem' }}>WhatsApp Business API</h2>
        <form onSubmit={save} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div>
            <label style={{ fontSize: 13, color: '#444441', display: 'block', marginBottom: 4 }}>Token de acesso</label>
            <input value={token} onChange={e => setToken(e.target.value)} placeholder="EAAxxxxxxx..." style={{ width: '100%' }} />
          </div>
          <div>
            <label style={{ fontSize: 13, color: '#444441', display: 'block', marginBottom: 4 }}>Phone Number ID</label>
            <input value={phoneId} onChange={e => setPhoneId(e.target.value)} placeholder="1234567890" style={{ width: '100%' }} />
          </div>
          <p style={{ fontSize: 12, color: '#888780', lineHeight: 1.5 }}>
            Obtenha essas informações no <a href="https://developers.facebook.com" target="_blank" rel="noreferrer">Meta for Developers</a> → seu App → WhatsApp → API Setup.
          </p>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <button type="submit" className="primary">Salvar configurações</button>
            {saved && <span style={{ fontSize: 13, color: '#0F6E56' }}>✓ Salvo!</span>}
          </div>
        </form>
      </div>
    </div>
  )
}
