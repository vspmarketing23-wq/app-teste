import React from 'react'
import { NavLink } from 'react-router-dom'

const nav = [
  { to: '/send', label: '📤 Novo Disparo' },
  { to: '/campaigns', label: '📋 Histórico' },
  { to: '/settings', label: '⚙️ Configurações' },
]

export default function Layout({ children, onLogout }) {
  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <aside style={{
        width: 220, background: 'white', borderRight: '1px solid #D3D1C7',
        display: 'flex', flexDirection: 'column', padding: '1.5rem 1rem'
      }}>
        <div style={{ fontWeight: 700, fontSize: 16, marginBottom: '2rem', color: '#0F6E56' }}>
          📱 WA Sender
        </div>
        <nav style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 4 }}>
          {nav.map(n => (
            <NavLink key={n.to} to={n.to} style={({ isActive }) => ({
              padding: '8px 12px', borderRadius: 6, fontSize: 14, color: isActive ? '#0F6E56' : '#444441',
              background: isActive ? '#E1F5EE' : 'transparent', fontWeight: isActive ? 500 : 400,
              textDecoration: 'none'
            })}>
              {n.label}
            </NavLink>
          ))}
        </nav>
        <button onClick={onLogout} style={{ fontSize: 13, color: '#888780', border: 'none', background: 'none', cursor: 'pointer', textAlign: 'left', padding: '8px 12px' }}>
          Sair
        </button>
      </aside>
      <main style={{ flex: 1, overflow: 'auto' }}>
        {children}
      </main>
    </div>
  )
}
